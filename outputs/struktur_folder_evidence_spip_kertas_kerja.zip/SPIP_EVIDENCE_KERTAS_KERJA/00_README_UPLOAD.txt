Struktur folder evidence SPIP berdasarkan Kertas Kerja PM SPIP 2026.

Pola folder:
KK -> Subunsur -> Detail parameter -> Grade.

File evidence diupload langsung ke folder Grade A-E masing-masing.

Gunakan 00_MANIFEST_STRUKTUR.csv untuk audit mapping folder dengan kertas kerja.